function SoundButton(srcImage,srcSound){
    
}