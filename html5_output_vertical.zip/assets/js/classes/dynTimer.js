function DynTimer(){
    
}