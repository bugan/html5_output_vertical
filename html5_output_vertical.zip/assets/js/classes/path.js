function Path() {
	
	this.beginPoint = new Point();
	this.endPoint = new Point();
	
}