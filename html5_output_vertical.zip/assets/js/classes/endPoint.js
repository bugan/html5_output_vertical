function EndPoint(positionX,positionY,quizNumber){
    this.quizNumber = quizNumber;
    this.posX = positionX;
    this.posY = positionY;
    this.alreadyAwsered = false;
}


