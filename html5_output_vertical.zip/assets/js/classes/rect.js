function Rect(iniX,iniY,width,height) {
	
	
	this.iniX = iniX;
	this.iniY =  iniY;
	this.width = width;
	this.height = height;
	
	this.x = 0;
	this.y = 0;
	
}