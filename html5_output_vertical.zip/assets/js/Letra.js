function Letra(index,rect){
    this.rect = rect;
    this.index = index;
    this.isActivated = false;
    this.canClick = true;
}